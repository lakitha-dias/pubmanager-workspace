package com.pairlearning.expensetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
